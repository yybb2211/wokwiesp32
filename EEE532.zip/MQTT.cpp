
#include "MQTT.h"


// -------- WiFi 配置 --------
const char* WIFI_SSID     = "Wokwi-GUEST";
const char* WIFI_PASSWORD = "";

// -------- MQTT 配置 --------
// const char* MQTT_BROKER   = "mqtt.cloud.thingsboard.io";
const char* MQTT_BROKER   = "mqtt.thingsboard.cloud";

const int   MQTT_PORT     = 1883;
const char* MQTT_CLIENT_ID = "microthon-weather-demo";
const char* MQTT_TOPIC_esp32     = "v1/devices/me/ESP32YZL";

// 用户名 = 设备 AccessToken
const char* MQTT_USER   = "LbUewRvumZifp7fr8BlV";
// 23488670-45ec-11f1-b7a8-75be0d5c4df2
const char* MQTT_PASS   = ""; 
// const char* MQTT_BROKER   = "broker.mqttdashboard.com";
// const int   MQTT_PORT     = 1883;
// const char* MQTT_TOPIC_weather     = "wokwi-weather";
// const char* MQTT_TOPIC_mpu6050     = "wokwi-mpu6050";
// -------- 全局 MQTT 客户端 --------
WiFiClient espClient;
PubSubClient mqttClient(espClient);
float temp,hum; 
// 上一次发送的 JSON，用于比较“是否变化”
String prevWeather = "";
String prevmpu6050 = "";
extern DHTesp dht;
// 连接 WiFi
void connectWiFi() {
  Serial.print("Connecting to WiFi");
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  while (WiFi.status() != WL_CONNECTED) {
    Serial.print(".");
    delay(100);
  }
  Serial.println(" Connected!");
}

// 连接 MQTT
void connectMQTT() {
  mqttClient.setServer(MQTT_BROKER, MQTT_PORT);

  while (!mqttClient.connected()) {
    Serial.print("Connecting to MQTT...");
    if (mqttClient.connect(MQTT_CLIENT_ID, MQTT_USER, MQTT_PASS)) {
      Serial.println(" connected!");
    } else {
      Serial.print(" failed, rc=");
      Serial.print(mqttClient.state());
      Serial.println(" try again in 2 seconds");
      delay(2000);
    }
  }
}

// 发布数据
// void publishWeatherData(const String& data) {
//   Serial.print("Measuring weather conditions... ");
//   if (mqttClient.publish(MQTT_TOPIC_weather, data.c_str())) {
//     Serial.print("Published: ");
//     Serial.println(data);
//   } else {
//     Serial.println("Publish failed");
//   }
// }
// void publishmpu6050Data(const String& data) {
//   Serial.print("Measuring mpu6050 conditions... ");
//   if (mqttClient.publish(MQTT_TOPIC_mpu6050, data.c_str())) {
//     Serial.print("Published: ");
//     Serial.println(data);
//   } else {
//     Serial.println("Publish failed");
//   }
// }
void publishData(const String& data) {
  Serial.print("Measuring conditions... ");
  if (mqttClient.publish(MQTT_TOPIC_esp32, data.c_str())) {
    Serial.print("Published: ");
    Serial.println(data);
  } else {
    Serial.println("Publish failed");
  }
}
void send_data(void)
{
  // 确保 MQTT 连接保持
  if (!mqttClient.connected()) {
    connectMQTT();
  }
  mqttClient.loop();  // 处理 MQTT 内部事务

  // 读取 DHT22
  TempAndHumidity data = dht.getTempAndHumidity();
  temp = data.temperature;
  hum  = data.humidity;

   String json = "{";
  json += "\"ax\":" + String(a.acceleration.x,2) + ",";
  json += "\"ay\":" + String(a.acceleration.y,2) + ",";
  json += "\"az\":" + String(a.acceleration.z,2) + ",";
  json += "\"gx\":" + String(g.gyro.x,2) + ",";
  json += "\"gy\":" + String(g.gyro.y,2) + ",";
  json += "\"gz\":" + String(g.gyro.z,2) + ",";
  json += "\"tempmpu\":" + String(t.temperature,1) + ",";
  json += "\"tempDHT\":" + String(temp,1) + ",";
  json += "\"hum\":" + String(hum,1) + ",";
  // json += "\"pid\":" + String(outputAngle,1) + ",";
  json += "\"pump\":" + String(currentPumpState ? 1 : 0);
  json += "}";

  Serial.println("upload data!");
  publishData(json);
  // // 构造 JSON 字符串（不使用 ArduinoJson，直接手拼）
  // String weather = "{";
  // weather += "\"temp\":";
  // weather += String(temp, 1);       // 保留 1 位小数
  // weather += ",\"humidity\":";
  // weather += String(hum, 1);
  // weather += "}";
  // String mpu6050_data = "{";
  // // 加速度组
  // mpu6050_data += "\"Acceleration\":{";
  // mpu6050_data += "\"x\":" + String(a.acceleration.x, 1) + ",";
  // mpu6050_data += "\"y\":" + String(a.acceleration.y, 1) + ",";
  // mpu6050_data += "\"z\":" + String(a.acceleration.z, 1) + "},";
  // // 陀螺仪组
  // mpu6050_data += "\"Rotation\":{";
  // mpu6050_data += "\"x\":" + String(g.gyro.x, 1) + ",";
  // mpu6050_data += "\"y\":" + String(g.gyro.y, 1) + ",";
  // mpu6050_data += "\"z\":" + String(g.gyro.z, 1) + "},";
  // // 温度
  // mpu6050_data += "\"Temperature\":" + String(t.temperature, 1);
  // mpu6050_data += "}";

  // 只有变化才发送
//   if (weather != prevWeather) 
//   {
//     Serial.println("Updated! weather");
//     publishWeatherData(weather);
//     prevWeather = weather;
//   } 
//   else if (weather == prevWeather)
//   {
//     Serial.println("No change weather");
//   }
//  // Serial.println(prevmpu6050);
//   if(mpu6050_data != prevmpu6050)
//   {
//     Serial.println("Updated! mpu6050_data");
//     publishmpu6050Data(mpu6050_data);
//     prevmpu6050 = mpu6050_data;
//   }
//   else if(mpu6050_data == prevmpu6050)
//   {
//        Serial.println("No change mpu6050");
//   }

  delay(2000);  // 对应 MicroPython 里的 time.sleep(2)
}