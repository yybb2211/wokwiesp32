#include "Motor.h"
const float HUM_LOW = 80.0;
PumpState currentPumpState = PUMP_OFF;
void motor_init()
{
  pinMode(Motor_PIN, OUTPUT);
  digitalWrite(Motor_PIN, LOW);
  currentPumpState = PUMP_OFF;
}
void calculate_Motor()
{
    if(hum<HUM_LOW)
    {
        digitalWrite(Motor_PIN, HIGH);
        currentPumpState = PUMP_ON;
    }
    else
    {
      digitalWrite(Motor_PIN, LOW);
      currentPumpState = PUMP_OFF;
    }
    // 2. 串口输出：把枚举值转成字符串
    if (currentPumpState == PUMP_ON)
    {
        Serial.println("Pump Status: ON!!!");
    }
    else
    {
        Serial.println("Pump Status: OFF!!!");
    }
}