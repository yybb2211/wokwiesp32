// ESP32 + DHT22 + MQTT (等价于你的 main.py + MQTT.py)

// #include <WiFi.h>
// #include <PubSubClient.h>
#include "DHTesp.h"
#include "MQTT.h"
#include "Motor.h"
#include "OLED.h"
#include "mpu6050.h"


// -------- DHT22 配置 --------
const int DHT_PIN = 15;     // 和你 MicroPython 版本一样
DHTesp dht;
// // OLED
// extern SSD1306Wire display;
// extern LiquidCrystal_I2C lcd(I2C_ADDR, LCD_COLUMNS, LCD_LINES);


void setup() {
  Serial.begin(115200);
  // 初始化 OLED
  display.init();
  display.flipScreenVertically();
  display.clear();
  display.drawString(0, 0, "System Starting...");
  display.display();

  // Init
  lcd.init();
  lcd.backlight();
  lcd.setCursor(0,0);lcd.print("System Starting...");

  
  //初始化 DHT22 继电器
  dht.setup(DHT_PIN, DHTesp::DHT22);
  motor_init();
  mpu5060_Init();
  // WiFi + MQTT
  connectWiFi();
  connectMQTT();
}

void loop() 
{
  send_data();
  calculate_Motor();
  //show_oled();
  mpu5060_calculate();
  show();


}
