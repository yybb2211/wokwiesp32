// #include <SSD1306Wire.h>
#include "OLED.h"
#define I2C_ADDR    0x27
#define LCD_COLUMNS 20
#define LCD_LINES   4
//extern sensors_event_t a, g, t;
// // OLED
SSD1306Wire display(0x3C, SDA, SCL);
LiquidCrystal_I2C lcd(I2C_ADDR, LCD_COLUMNS, LCD_LINES);
void show_oled()
{

  // ------------ 新增：OLED 刷新代码 ------------
  display.clear();
  display.setFont(ArialMT_Plain_16);
  
  // 显示温度
  display.drawString(0, 0, "Temp: " + String(temp,1) + " C");
  // 显示湿度
  display.drawString(0, 20, "Hum: " + String(hum,1) + " %");
  // 显示水泵状态（和你的Motor代码联动）
  String pumpStatus = (digitalRead(Motor_PIN) == HIGH) ? "Pump: ON" : "Pump: OFF";
  display.drawString(0, 40, pumpStatus);
  
  display.display(); // 刷新屏幕
  // -------------------------------------------
}

void show_lcd()
{
  // 2004 LCD 完整版显示（一次性展示所有内容）

  lcd.begin(20, 4);
    // 第1行：加速度
    lcd.setCursor(0,0);
    lcd.print("AX:"); lcd.print(a.acceleration.x,1);
    lcd.print(" Y:"); lcd.print(a.acceleration.y,1);
    lcd.print(" Z:"); lcd.print(a.acceleration.z,1);
    
    // 第2行：陀螺仪
    lcd.setCursor(0,1);
    lcd.print("RX:"); lcd.print(g.gyro.x,1);
    lcd.print(" Y:"); lcd.print(g.gyro.y,1);
    lcd.print(" Z:"); lcd.print(g.gyro.z,1);
    
    // 第3行：温度
    lcd.setCursor(0,2);
    lcd.print("Temp:"); lcd.print(t.temperature,2);
    lcd.print(" degC");
    
    // 第4行：PID输出
    // lcd.setCursor(0,3);
    // lcd.print("PID Out:"); lcd.print(outputAngle,2);

}
void show()
{
  show_lcd();
  show_oled();
}


