#ifndef MQTT_H
#define MQTT_H

#include <WiFi.h>
#include <PubSubClient.h>
#include "Motor.h"
#include "DHTesp.h"
#include "mpu6050.h"

// // -------- WiFi 配置 --------
// const char* WIFI_SSID     = "Wokwi-GUEST";
// const char* WIFI_PASSWORD = "";

// // -------- MQTT 配置 --------
// const char* MQTT_BROKER   = "broker.mqttdashboard.com";
// const int   MQTT_PORT     = 1883;
// const char* MQTT_CLIENT_ID = "microthon-weather-demo";
// const char* MQTT_TOPIC     = "wokwi-weather";

// WiFi
extern const char* WIFI_SSID;
extern const char* WIFI_PASSWORD;

// MQTT
extern const char* MQTT_BROKER;
extern const int   MQTT_PORT;
extern const char* MQTT_CLIENT_ID;
extern const char* MQTT_TOPIC_weather;
extern const char* MQTT_TOPIC_mpu6050;

extern const char* MQTT_USER ;
extern const char* MQTT_PASS; 

// 在别处需要用到的全局对象也声明一下
extern WiFiClient espClient;
extern PubSubClient mqttClient;
extern String prevWeather;

// 函数声明（供 main.cpp 等文件调用）
void connectWiFi();
void connectMQTT();
// void publishWeatherData(const String& data);
// void publishmpu6050Data(const String& data);
void publishData(const String& data);
void send_data(void);

#endif // MQTT_H

