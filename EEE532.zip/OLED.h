#ifndef OLED_H
#define OLED_H

#include <Adafruit_MPU6050.h>
#include <Arduino.h>
#include <SSD1306Wire.h>
#include <LiquidCrystal_I2C.h>
#include <LiquidCrystal.h>
#include "mpu6050.h"
#include "Motor.h"


extern float temp,hum;
extern LiquidCrystal_I2C lcd;
extern SSD1306Wire display;
void show();
#endif