#ifndef MPU6050_H
#define MPU6050_H

#include <Arduino.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>
#include <Wire.h>
const int AD0pin = 16;
const int mpuAddr = 0x68;  // I2C address
const int mpuAddr_not_used = 0x69; // not even used in the code.
extern sensors_event_t a, g, t;
// 继电器控制脚（你图里蓝线接到哪个 GPIO，就写哪个）
// 比如接的是 GPIO 25：


// 对外提供的初始化 & 逻辑函数
void mpu5060_Init();
void mpu5060_calculate();

#endif
