#ifndef MOTOR_H
#define MOTOR_H

#include <Arduino.h>

// 继电器控制脚（你图里蓝线接到哪个 GPIO，就写哪个）
// 比如接的是 GPIO 25：
//---------继电器配置-------------
#define Motor_PIN 25
extern float temp,hum;
// 1. 定义水泵状态枚举
enum PumpState {
    PUMP_OFF = 0,
    PUMP_ON = 1
};
extern PumpState currentPumpState;
// 对外提供的初始化 & 逻辑函数
void motor_init();
void calculate_Motor();

#endif
